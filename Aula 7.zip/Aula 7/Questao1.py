import os

nome_arquivo = 'alunos.txt'

def limpar_tela():
    """Limpa a tela do console."""
    os.system('cls' if os.name == 'nt' else 'clear')

def adicionar_aluno(lista_alunos):
    """Adiciona um aluno e calcula sua média."""
    limpar_tela()
    print("--- CADASTRO DE ALUNO ---")
    
    nome = input("Nome do aluno: ")
    notas = []
    
    while True:
        try:
            qtd_notas = int(input("Quantidade de notas a registrar (2 a 5): "))
            if 2 <= qtd_notas <= 5:
                break
            print("Erro: A quantidade deve ser entre 2 e 5.")
        except ValueError:
            print("Erro: Digite um número inteiro.")

    for i in range(qtd_notas):
        while True:
            try:
                nota = float(input(f"Nota {i+1}: "))
                if 0 <= nota <= 10:
                    notas.append(nota)
                    break
                print("Erro: A nota deve estar entre 0 e 10.")
            except ValueError:
                print("Erro: Digite um valor numérico válido.")
                
    media = sum(notas) / len(notas)
    
    novo_aluno = {
        "nome": nome,
        "notas": notas,
        "media": media
    }
    
    lista_alunos.append(novo_aluno)
    print("\nAluno adicionado com sucesso!")
    input("Pressione Enter para continuar...")
    return lista_alunos

def ordenar_alunos(lista_alunos):
    """Ordena a lista de alunos pela média de forma decrescente."""
    lista_alunos.sort(key=lambda x: x['media'], reverse=True)
    return lista_alunos

def salvar_em_arquivo(lista_alunos):
    """Salva os dados dos alunos no arquivo txt."""
    if not lista_alunos:
        return

    if os.path.exists(nome_arquivo):
        sobrescrever = input(f"\nO arquivo '{nome_arquivo}' já existe. Deseja sobrescrever? (S/N): ").strip().upper()
        if sobrescrever != 'S':
            print("Operação de salvamento cancelada.")
            return

    try:
        with open(nome_arquivo, 'w', encoding='utf-8') as f:
            for aluno in lista_alunos:
                f.write(f"{aluno['nome']},{aluno['media']:.2f}\n")
        print(f"\nOs dados foram salvos no arquivo '{nome_arquivo}'.")
    except PermissionError:
        print("\nErro: Sem permissão para gravar o arquivo.")
    except Exception as e:
        print(f"\nErro ao tentar salvar o arquivo: {e}")

def main():
    """Função principal que gerencia o menu."""
    lista_alunos = []
    
    while True:
        limpar_tela()
        print("--- SISTEMA DE GESTÃO DE NOTAS ---")
        print("1. Adicionar Aluno")
        print("2. Finalizar e Mostrar Relatório")
        
        opcao = input("\nEscolha uma opção: ")
        
        if opcao == '1':
            lista_alunos = adicionar_aluno(lista_alunos)
        elif opcao == '2':
            limpar_tela()
            print("--- RELATÓRIO FINAL ---")
            lista_alunos = ordenar_alunos(lista_alunos)
            
            if lista_alunos:
                print("Alunos ordenados por média:")
                for aluno in lista_alunos:
                    print(f"{aluno['nome']} - Média: {aluno['media']:.2f}")
                salvar_em_arquivo(lista_alunos)
            else:
                print("Nenhum aluno cadastrado.")
                
            print("\nEncerrando o programa...")
            break
        else:
            print("Opção inválida.")
            input("Pressione Enter para tentar novamente...")

if __name__ == '__main__':
    main()