import os

nome_arquivo = 'biblioteca.txt'

def limpar_tela():
    """Limpa a tela do console."""
    os.system('cls' if os.name == 'nt' else 'clear')

def carregar_livros():
    """Lê os dados do arquivo de texto e retorna uma lista de dicionários."""
    lista_livros = []
    if os.path.exists(nome_arquivo):
        try:
            with open(nome_arquivo, 'r', encoding='utf-8') as f:
                for linha in f:
                    titulo, autor, ano, paginas = linha.strip().split(',')
                    livro = {
                        "titulo": titulo,
                        "autor": autor,
                        "ano": int(ano),
                        "paginas": int(paginas)
                    }
                    lista_livros.append(livro)
        except PermissionError:
            print("Erro: Sem permissão para ler o arquivo.")
            input("Pressione Enter para continuar...")
        except Exception:
            print("Erro ao tentar ler o arquivo ou formato inválido.")
            input("Pressione Enter para continuar...")
    return lista_livros

def salvar_livros(lista_livros):
    """Salva os livros no arquivo de texto."""
    try:
        with open(nome_arquivo, 'w', encoding='utf-8') as f:
            for livro in lista_livros:
                f.write(f"{livro['titulo']},{livro['autor']},{livro['ano']},{livro['paginas']}\n")
        print(f"\nOs dados foram salvos no arquivo '{nome_arquivo}'.")
    except PermissionError:
        print("\nErro: Sem permissão para gravar o arquivo.")
    except Exception as e:
        print(f"\nErro ao tentar salvar o arquivo: {e}")

def adicionar_livro(lista_livros):
    """Adiciona um novo livro à lista."""
    limpar_tela()
    print("--- CADASTRO DE LIVRO ---")
    
    titulo = input("Título do livro: ")
    autor = input("Autor: ")
    
    while True:
        try:
            ano = int(input("Ano de publicação: "))
            if ano <= 0:
                raise ValueError
            break
        except ValueError:
            print("Erro: O ano deve ser um número inteiro positivo.")
            
    while True:
        try:
            paginas = int(input("Número de páginas: "))
            if paginas <= 0:
                raise ValueError
            break
        except ValueError:
            print("Erro: O número de páginas deve ser um inteiro positivo.")

    novo_livro = {
        "titulo": titulo,
        "autor": autor,
        "ano": ano,
        "paginas": paginas
    }
    
    lista_livros.append(novo_livro)
    print("\nLivro adicionado com sucesso!")
    input("Pressione Enter para continuar...")
    return lista_livros

def listar_livros(lista_livros):
    """Mostra todos os livros cadastrados na tela."""
    limpar_tela()
    print("--- LISTA DE LIVROS ---")
    
    if not lista_livros:
        print("Nenhum livro cadastrado.")
    else:
        for i, livro in enumerate(lista_livros):
            print(f"[{i + 1}] Título: {livro['titulo']} | Autor: {livro['autor']}")
            print(f"    Ano: {livro['ano']} | Páginas: {livro['paginas']}")
            print("-" * 40)
            
    input("\nPressione Enter para voltar ao menu...")

def ordenar_livros(lista_livros):
    """Ordena a lista de livros por ano ou páginas."""
    limpar_tela()
    print("--- ORDENAR LIVROS ---")
    
    if not lista_livros:
        print("Nenhum livro cadastrado para ordenar.")
        input("Pressione Enter para continuar...")
        return lista_livros

    print("1. Ordenar por Ano")
    print("2. Ordenar por Páginas")
    escolha = input("\nEscolha a opção: ")
    
    print("\n1. Crescente")
    print("2. Decrescente")
    ordem = input("Escolha a ordem: ")
    
    reverso = True if ordem == '2' else False
    
    if escolha == '1':
        lista_livros.sort(key=lambda x: x['ano'], reverse=reverso)
        print("\nLista ordenada por ano.")
    elif escolha == '2':
        lista_livros.sort(key=lambda x: x['paginas'], reverse=reverso)
        print("\nLista ordenada por páginas.")
    else:
        print("\nOpção inválida.")
        
    input("Pressione Enter para continuar...")
    return lista_livros

def main():
    """Função principal e menu da biblioteca."""
    lista_livros = []
    
    while True:
        limpar_tela()
        print("Bem-vindo à Biblioteca Digital!")
        print("Escolha uma opção:")
        print("1. Adicionar livro")
        print("2. Listar livros")
        print("3. Ordenar livros")
        print("4. Salvar dados em arquivo")
        print("5. Carregar dados do arquivo")
        print("6. Sair")
        
        opcao = input("\n> ")
        
        if opcao == '1':
            lista_livros = adicionar_livro(lista_livros)
        elif opcao == '2':
            listar_livros(lista_livros)
        elif opcao == '3':
            lista_livros = ordenar_livros(lista_livros)
        elif opcao == '4':
            salvar_livros(lista_livros)
            input("\nPressione Enter para continuar...")
        elif opcao == '5':
            lista_livros = carregar_livros()
            print("\nDados carregados com sucesso.")
            input("Pressione Enter para continuar...")
        elif opcao == '6':
            salvar = input("\nDeseja salvar os dados antes de sair? (S/N): ").strip().upper()
            if salvar == 'S':
                salvar_livros(lista_livros)
            print("Saindo do programa...")
            break
        else:
            print("Opção inválida.")
            input("Pressione Enter para tentar novamente...")

if __name__ == '__main__':
    main()