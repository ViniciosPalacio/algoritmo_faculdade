import os

nome_arquivo = 'estoque.txt'

def limpar_tela():
    """Limpa a tela do console."""
    os.system('cls' if os.name == 'nt' else 'clear')

def carregar_estoque():
    """Lê os dados do arquivo de texto e retorna a lista de produtos."""
    lista_produtos = []
    if os.path.exists(nome_arquivo):
        try:
            with open(nome_arquivo, 'r', encoding='utf-8') as f:
                for linha in f:
                    nome, categoria, preco, quantidade = linha.strip().split(',')
                    produto = {
                        "nome": nome,
                        "categoria": categoria,
                        "preco": float(preco),
                        "quantidade": int(quantidade)
                    }
                    lista_produtos.append(produto)
        except PermissionError:
            print("Erro: Sem permissão para ler o arquivo.")
            input("Pressione Enter para continuar...")
        except Exception:
            print("Erro ao tentar ler o arquivo ou formato inválido.")
            input("Pressione Enter para continuar...")
    return lista_produtos

def salvar_estoque(lista_produtos):
    """Salva a lista de produtos no arquivo txt."""
    try:
        with open(nome_arquivo, 'w', encoding='utf-8') as f:
            for produto in lista_produtos:
                f.write(f"{produto['nome']},{produto['categoria']},{produto['preco']},{produto['quantidade']}\n")
        print(f"\nOs dados foram salvos no arquivo '{nome_arquivo}'.")
    except PermissionError:
        print("\nErro: Sem permissão para gravar o arquivo.")
    except Exception as e:
        print(f"\nErro ao tentar salvar o arquivo: {e}")

def adicionar_produto(lista_produtos):
    """Cadastra um novo produto no estoque."""
    limpar_tela()
    print("--- CADASTRO DE PRODUTO ---")
    
    nome = input("Nome do produto: ")
    categoria = input("Categoria: ")
    
    while True:
        try:
            preco = float(input("Preço: "))
            if preco <= 0:
                raise ValueError
            break
        except ValueError:
            print("Erro: O preço deve ser um valor numérico positivo.")
            
    while True:
        try:
            quantidade = int(input("Quantidade: "))
            if quantidade < 0:
                raise ValueError
            break
        except ValueError:
            print("Erro: A quantidade deve ser um número inteiro positivo ou zero.")

    novo_produto = {
        "nome": nome,
        "categoria": categoria,
        "preco": preco,
        "quantidade": quantidade
    }
    
    lista_produtos.append(novo_produto)
    print("\nProduto adicionado com sucesso!")
    input("Pressione Enter para continuar...")
    return lista_produtos

def atualizar_quantidade(lista_produtos):
    """Atualiza a quantidade de um produto específico."""
    limpar_tela()
    print("--- ATUALIZAR QUANTIDADE ---")
    
    if not lista_produtos:
        print("Nenhum produto cadastrado.")
        input("Pressione Enter para continuar...")
        return lista_produtos

    busca = input("Digite o nome exato do produto: ")
    
    for produto in lista_produtos:
        if produto["nome"].lower() == busca.lower():
            while True:
                try:
                    nova_qtd = int(input(f"Nova quantidade para '{produto['nome']}' (Atual: {produto['quantidade']}): "))
                    if nova_qtd < 0:
                        raise ValueError
                    produto["quantidade"] = nova_qtd
                    print("\nQuantidade atualizada com sucesso.")
                    input("Pressione Enter para continuar...")
                    return lista_produtos
                except ValueError:
                    print("Erro: Digite um número inteiro válido.")
                    
    print("\nProduto não encontrado.")
    input("Pressione Enter para continuar...")
    return lista_produtos

def listar_produtos(lista_produtos):
    """Mostra todos os produtos cadastrados."""
    limpar_tela()
    print("--- LISTA DE PRODUTOS ---")
    
    if not lista_produtos:
        print("Nenhum produto cadastrado no estoque.")
    else:
        for i, produto in enumerate(lista_produtos):
            print(f"[{i + 1}] Nome: {produto['nome']} | Categoria: {produto['categoria']}")
            print(f"    Preço: R$ {produto['preco']:.2f} | Quantidade: {produto['quantidade']}")
            print("-" * 40)
            
    input("\nPressione Enter para voltar ao menu...")

def ordenar_produtos(lista_produtos):
    """Ordena a lista de produtos por preço ou quantidade."""
    limpar_tela()
    print("--- ORDENAR PRODUTOS ---")
    
    if not lista_produtos:
        print("Nenhum produto cadastrado para ordenar.")
        input("Pressione Enter para continuar...")
        return lista_produtos

    print("1. Ordenar por Preço")
    print("2. Ordenar por Quantidade")
    escolha = input("\nEscolha a opção: ")
    
    print("\n1. Crescente")
    print("2. Decrescente")
    ordem = input("Escolha a ordem: ")
    
    reverso = True if ordem == '2' else False
    
    if escolha == '1':
        lista_produtos.sort(key=lambda x: x['preco'], reverse=reverso)
        print("\nLista ordenada por preço.")
    elif escolha == '2':
        lista_produtos.sort(key=lambda x: x['quantidade'], reverse=reverso)
        print("\nLista ordenada por quantidade.")
    else:
        print("\nOpção inválida.")
        
    input("Pressione Enter para continuar...")
    return lista_produtos

def main():
    """Menu principal do sistema de estoque."""
    lista_produtos = []
    
    while True:
        limpar_tela()
        print("Bem-vindo ao Sistema de Gestão de Estoque!")
        print("Escolha uma opção:")
        print("1. Adicionar produto")
        print("2. Atualizar quantidade")
        print("3. Listar produtos")
        print("4. Ordenar produtos")
        print("5. Salvar dados em arquivo")
        print("6. Carregar dados do arquivo")
        print("7. Sair")
        
        opcao = input("\n> ")
        
        if opcao == '1':
            lista_produtos = adicionar_produto(lista_produtos)
        elif opcao == '2':
            lista_produtos = atualizar_quantidade(lista_produtos)
        elif opcao == '3':
            listar_produtos(lista_produtos)
        elif opcao == '4':
            lista_produtos = ordenar_produtos(lista_produtos)
        elif opcao == '5':
            salvar_estoque(lista_produtos)
            input("\nPressione Enter para continuar...")
        elif opcao == '6':
            lista_produtos = carregar_estoque()
            print("\nDados carregados com sucesso.")
            input("Pressione Enter para continuar...")
        elif opcao == '7':
            salvar = input("\nDeseja salvar o estoque antes de sair? (S/N): ").strip().upper()
            if salvar == 'S':
                salvar_estoque(lista_produtos)
            print("Saindo do programa...")
            break
        else:
            print("Opção inválida.")
            input("Pressione Enter para tentar novamente...")

if __name__ == '__main__':
    main()